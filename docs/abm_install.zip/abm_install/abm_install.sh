#!/usr/bin/env bash

####ABM INSTALLATION#####
#########################


LOGFILE=$HOME/`date "+%F %T"`\ $USER.log
user=${user:-abm}
mailid=${mailid:-agupta@mail.uni-paderborn.de}
MYSQL_ROOT_PASSWORD=${MYSQL_ROOT_PASSWORD:-'password'} # SET THIS! Avoid quotes/apostrophes in the password, but do use lowercase + uppercase + numbers + special chars
HERMES_CONFIG_DIR=${HERMES_CONFIG_DIR:-"/opt/abm"}


######Git Repository######
##########################

if hash git 2>/dev/null
then
  sudo -u abm git clone https://github.com/ABenchM/abm.git 2>&1 >> "$LOGFILE"
else
  apt-get install git -y && sudo -u ${user} git clone https://github.com/ABenchM/abm.git 2>&1 >> "$LOGFILE"
fi


#######Docker Setup######
#########################

if hash docker 2>/dev/null
then
  echo "Docker Installed" >> "$LOGFILE"
else
  # Docker
 apt-get remove --yes docker docker-engine docker.io \
    && apt-get update \
    && apt-get --yes --no-install-recommends install \
        apt-transport-https \
        ca-certificates \
    && wget --quiet --output-document=- https://download.docker.com/linux/ubuntu/gpg \
        |  apt-key add - \
    &&  add-apt-repository \
        "deb [arch=$(dpkg --print-architecture)] https://download.docker.com/linux/ubuntu \
        $(lsb_release --codename --short) \
        stable" \
    &&  apt-get update \
    &&  apt-get --yes --no-install-recommends install docker-ce \
    &&  usermod --append --groups docker "$user" \
    &&  systemctl enable docker \
    && printf '\nDocker installed successfully\n\n'

printf 'Waiting for Docker to start...\n\n'
sleep 3 
fi 

# Docker Compose   
if hash docker-compose 2>/dev/null
   then
    echo "Docker compose already Installted" >> "$LOGFILE"
else
  wget \
        --output-document=/usr/local/bin/docker-compose \
        https://github.com/docker/compose/releases/download/1.19.0/run.sh \
    && chmod +x /usr/local/bin/docker-compose \
    && wget \
        --output-document=/etc/bash_completion.d/docker-compose \
        "https://raw.githubusercontent.com/docker/compose/$(docker-compose version --short)/contrib/completion/bash/docker-compose" \
    && printf '\nDocker Compose installed successfully\n\n' >> "$LOGFILE"
fi    

##Installing Images
    
docker-compose up -d --no-recreate >> "$LOGFILE"

#Creating Volumes

docker volume create --name IVY_REPO -d local >/dev/null >> "$LOGFILE"

docker volume create --name M2_REPO -d local >> "$LOGFILE"

########MySQl Setup#####
########################


export DEBIAN_FRONTEND=noninteractive
echo debconf mysql-server/root_password password $MYSQL_ROOT_PASSWORD |  debconf-set-selections
echo debconf mysql-server/root_password_again password $MYSQL_ROOT_PASSWORD |  debconf-set-selections
apt-get -qq install mysql-server > /dev/null >> "$LOGFILE"

# Install Expect
apt-get -qq install expect > /dev/null >> "$LOGFILE"

# Build Expect script
tee ~/secure_our_mysql.sh > /dev/null << EOF
spawn $(which mysql_secure_installation)

expect "Enter password for user root:"
send "$MYSQL_ROOT_PASSWORD\r"

expect "Press y|Y for Yes, any other key for No:"
send "y\r"

expect "Please enter 0 = LOW, 1 = MEDIUM and 2 = STRONG:"
send "2\r"

expect "Change the password for root ? ((Press y|Y for Yes, any other key for No) :"
send "n\r"

expect "Remove anonymous users? (Press y|Y for Yes, any other key for No) :"
send "y\r"

expect "Disallow root login remotely? (Press y|Y for Yes, any other key for No) :"
send "y\r"

expect "Remove test database and access to it? (Press y|Y for Yes, any other key for No) :"
send "y\r"

expect "Reload privilege tables now? (Press y|Y for Yes, any other key for No) :"
send "y\r"

EOF

# Run Expect script.
# This runs the "mysql_secure_installation" script which removes insecure defaults.
expect ~/secure_our_mysql.sh >> "$LOGFILE"

# Cleanup
rm -v ~/secure_our_mysql.sh # Remove the generated Expect script
#sudo apt-get -qq purge expect > /dev/null # Uninstall Expect, commented out in case you need Expect

echo "MySQL setup completed." >> "$LOGFILE"

mysql -u root -p$MYSQL_ROOT_PASSWORD -e "create database abm"; >/dev/null >> "$LOGFILE"

mysql -u root -p$MYSQL_ROOT_PASSWORD -D abm < abm/bnd-workspace/de.fraunhofer.abm.useradmin.dao.jdbc/useradmin_ddl.sql && >> "$LOGFILE"

mysql -u root -p$MYSQL_ROOT_PASSWORD -D abm < abm/docs/abm.sql && >> "$LOGFILE"

#####Setting up Hermes config dir####
#####################################

mkdir -p $HERMES_CONFIG_DIR 2> /dev/null; >> "$LOGFILE"

cp abm/hermes_config/* /opt/abm/

#####Java Setup######
#####################

if hash java 2>/dev/null
then
   JAVA_CHECK=`java -version 2>&1`
   echo $JAVA_CHECK >> "$LOGFILE"
else
  apt-get install default-jdk -y >> "$LOGFILE"
fi

####Eclipse Set up######
########################

apt-get install eclipse -y 2>/dev/null >> "$LOGFILE"

cp eclipsed /usr/share/applications/eclipse.desktop && desktop-file-install /usr/share/applications/eclipse.desktop >> "$LOGFILE"

##Mailing the final logs#####
#############################

#mailx -s "ABM Installation finished" $mailid < "$LOGFILE"









       


